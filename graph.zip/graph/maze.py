import numpy as np
import cv2

class MazeGraph:
    def __init__(self, maze):



